from tkinter import *
a=Tk()
def sys():
    x1,y1,x2,y2 = box.bbox("marquee")
    if(x2<0 or y1<0): #reset the coordinates
        x1 = box.winfo_width()
        y1 = box.winfo_height()//2
        box.coords("marquee", x1,y1)
    else:
        box.move("marquee", -2, 0)
    box.after(1000//fps, sys)
a.title('TEKS BERLARI')
box=Canvas(a,bg='green')
box.pack(fill=Y, expand=1)
text_var=" ANJA BUNGA ADITYA "
text=box.create_text(1, 0, text=text_var,font=('Times New Roman',20,'bold'), tags = ("marquee"), fill='white')
x1,y1,x2,y2 = box.bbox("marquee")
width = x2-x1
height = y2-y1
box['width']=width
box['height']=height
fps=300
sys()
a.mainloop()